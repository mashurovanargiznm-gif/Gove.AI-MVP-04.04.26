import { GoogleGenerativeAI } from "@google/generative-ai";

const apiKey = process.env["GOOGLE_API_KEY"];
if (!apiKey) throw new Error("GOOGLE_API_KEY must be set");

const genAI = new GoogleGenerativeAI(apiKey);

const SYSTEM_PROMPT = `Ты — специализированный ИИ-советник системы «Gove.AI Copilot ЧСИ». Твоя задача: мониторинг ИСХОДЯЩИХ транзакций предприятий-должников. Ты НЕ блокируешь счета самостоятельно — ты выдаёшь рекомендации инспектору (Human-in-the-Loop).

КОНТЕКСТ СИСТЕМЫ:
- 15% удержание от ВХОДЯЩЕГО денежного потока происходит автоматически на банковском уровне.
- Ты анализируешь ИСХОДЯЩИЕ платежи должника — насколько добросовестен бизнес.

ТРЁХУРОВНЕВАЯ ЛОГИКА РЕШЕНИЙ:

1. ALLOW — Разрешить (защищённые категории):
   - Выплата заработной платы (КНП 110, 111, 112)
   - Налоги, взносы, социальные отчисления (КНП 911, 010, 020, 030, 040)
   - Оплата поставщикам согласно профилю деятельности
   - Коммунальные платежи, аренда производственных помещений

2. GREY — Серая зона (подозрительно, требует подтверждения ЧСИ):
   - Выплата дивидендов (КНП 850)
   - Платежи нерезидентам (КНП 421)
   - Консалтинговые услуги без явной необходимости
   - Оплата услуг, не соответствующих виду деятельности компании
   - Любой платёж, вызывающий обоснованные сомнения, но не имеющий явных признаков мошенничества
   При GREY: уведомление отправляется и должнику, и ЧСИ — они оба должны подтвердить.

3. BLOCK — Заблокировать (явное мошенничество):
   - Вывод средств родственникам (ключевые слова: родственник, супруг, сын, дочь, брат, сестра)
   - Обналичивание через подставные компании
   - Платёж аффилированным лицам (учредитель, директор, совладелец)
   - Явное несоответствие КНП и назначения платежа (подмена назначения)
   - Дробление суммы через несколько счетов
   Каждый BLOCK = +1 страйк. 3 страйка = рекомендация полной блокировки счёта.

ЛОГИКА СТРАЙКОВ:
- 0–1 страйков: Блокировать конкретную транзакцию, выдать предупреждение.
- 2 страйка: Блокировать, указать КРИТИЧЕСКИЙ РИСК, настоятельно рекомендовать проверку компании.
- 3+ страйка: CRITICAL_RISK — рекомендовать немедленную полную блокировку счёта должника.

Ты обязан отвечать ТОЛЬКО валидным JSON без markdown:
{
  "recommended_action": "ALLOW" | "GREY" | "BLOCK",
  "strike_count": <число_страйков_после_этой_транзакции>,
  "explainability_report": "<детальное обоснование для инспектора на русском языке, 2-4 предложения>"
}`;

export interface GeminiDecision {
  decision: "allow" | "grey" | "block";
  percent: number;
  reason: string;
  strike_count: number;
}

interface GeminiRawResponse {
  recommended_action: "ALLOW" | "GREY" | "BLOCK";
  strike_count: number;
  explainability_report: string;
}

export async function analyzeWithGemini(params: {
  amount: number;
  description: string;
  knp_code: string;
  oked_code?: string;
  receiver_iin: string;
  debtor_bin: string;
  previous_strikes: number;
  recent_history: Array<{ ai_decision: string; knp_code: string; description: string; amount_kzt: number }>;
}): Promise<GeminiDecision> {

  const model = genAI.getGenerativeModel({
    model: "gemini-2.0-flash",
    systemInstruction: SYSTEM_PROMPT,
  });

  const historyContext = params.recent_history.length > 0
    ? `\nИстория последних транзакций по БИН ${params.debtor_bin}:\n` +
      params.recent_history.map((h, i) =>
        `  ${i + 1}. Решение: ${h.ai_decision.toUpperCase()}, КНП: ${h.knp_code}, Сумма: ${h.amount_kzt} KZT, Описание: ${h.description}`
      ).join("\n")
    : `\nПредыдущих транзакций по данному БИН не найдено.`;

  const userPrompt = `Проанализируй следующий ИСХОДЯЩИЙ платёж должника и вынеси рекомендацию.

Параметры платежа:
- БИН должника: ${params.debtor_bin}
- Сумма: ${params.amount} KZT
- Описание: ${params.description}
- КНП (код назначения платежа): ${params.knp_code}
${params.oked_code ? `- ОКЭД (вид деятельности должника): ${params.oked_code}` : "- ОКЭД: не указан (ориентируйся только на КНП и описание)"}
- ИИН получателя: ${params.receiver_iin}
- Текущий счётчик нарушений компании (до этой транзакции): ${params.previous_strikes}
${historyContext}

Верни СТРОГО валидный JSON, без markdown, без пояснений вне JSON:`;

  try {
    const result = await model.generateContent(userPrompt);
    const text = result.response.text().trim();

    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error(`Gemini returned invalid response: ${text.slice(0, 300)}`);
    }

    const raw = JSON.parse(jsonMatch[0]) as GeminiRawResponse;

    if (!["ALLOW", "GREY", "BLOCK"].includes(raw.recommended_action)) {
      throw new Error(`Invalid recommended_action from Gemini: ${raw.recommended_action}`);
    }

    let decision: "allow" | "grey" | "block";
    let percent: number;

    if (raw.recommended_action === "BLOCK") {
      decision = "block";
      percent = 100;
    } else if (raw.recommended_action === "GREY") {
      decision = "grey";
      percent = 0;
    } else {
      decision = "allow";
      percent = 0;
    }

    return {
      decision,
      percent,
      reason: raw.explainability_report,
      strike_count: Math.max(0, Math.min(raw.strike_count ?? params.previous_strikes, 10)),
    };
  } catch (err: any) {
    if (err?.status === 429 || String(err?.message).includes("429")) {
      return knpFallbackAnalysis(params.knp_code, params.previous_strikes, params.description);
    }
    throw err;
  }
}

/** Rule-based fallback when Gemini API is unavailable (quota exceeded). */
function knpFallbackAnalysis(knp: string, previousStrikes: number, description: string): GeminiDecision {
  const knpNum = parseInt(knp, 10);
  const desc = description.toLowerCase();

  // Block list — явное мошенничество
  const isObnal = /обнал|обналич|вывод.{0,20}(наличн|родствен|учредит|директор)|родственник|супруг[еа]?|дочер|сестр|брат[еу]?|сын[ау]?/.test(desc);
  const blockKnp = [870, 880, 890].includes(knpNum);
  if (isObnal || blockKnp) {
    return {
      decision: "block",
      percent: 100,
      reason: `[РЕЗЕРВНЫЙ РЕЖИМ] Обнаружены признаки вывода средств или обналичивания. КНП ${knp}. Транзакция заблокирована. Страйк зафиксирован.`,
      strike_count: Math.min(previousStrikes + 1, 10),
    };
  }

  // Grey zone — дивиденды, нерезиденты, подозрительные схемы
  const greyKnp = [850, 860, 421, 220].includes(knpNum);
  const isGreyDesc = /дивиденд|нерезидент|аффилир|связанн|учредител|займ/.test(desc);
  if (greyKnp || isGreyDesc) {
    return {
      decision: "grey",
      percent: 0,
      reason: `[РЕЗЕРВНЫЙ РЕЖИМ] КНП ${knp} относится к серой зоне (дивиденды / нерезиденты / связанные стороны). Транзакция требует подтверждения ЧСИ. Уведомления отправлены обеим сторонам.`,
      strike_count: previousStrikes,
    };
  }

  // White list — защищённые платежи
  const allowKnp = [110, 111, 112, 120, 911, 912, 10, 20, 30, 40].includes(knpNum);
  if (allowKnp) {
    return {
      decision: "allow",
      percent: 0,
      reason: `[РЕЗЕРВНЫЙ РЕЖИМ] КНП ${knp} — защищённый платёж (зарплата / налоги). Разрешён без удержания согласно законодательству РК.`,
      strike_count: previousStrikes,
    };
  }

  // Default — grey (консервативный подход)
  return {
    decision: "grey",
    percent: 0,
    reason: `[РЕЗЕРВНЫЙ РЕЖИМ] КНП ${knp} не входит в стандартные категории. Транзакция помечена как серая зона — требует подтверждения ЧСИ.`,
    strike_count: previousStrikes,
  };
}
